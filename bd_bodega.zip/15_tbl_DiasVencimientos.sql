USE [ADSReports]
GO

/****** Object:  Table [dbo].[DiasVencimientos]    Script Date: 26/03/2020 7:29:45 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DiasVencimientos](
	[Complejidad] [nvarchar](256) NULL,
	[ConstruccionFSP ] [int] NULL,
	[EstimacionDesarrollo ] [int] NULL
) ON [PRIMARY]

GO


