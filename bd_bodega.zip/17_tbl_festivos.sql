USE [ADSReports]
GO

/****** Object:  Table [dbo].[festivos]    Script Date: 31/03/2020 11:24:20 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[festivos](
	[diafestivo] [datetime] NULL
) ON [PRIMARY]

GO

