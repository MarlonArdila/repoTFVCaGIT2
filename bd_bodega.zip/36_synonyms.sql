CREATE SYNONYM DimTeamProject  
FOR [ads_Warehouse].[dbo].[DimTeamProject];  
GO

 

CREATE SYNONYM DimWorkItem
FOR [ads_Warehouse].[dbo].DimWorkItem
GO

 

CREATE SYNONYM vFactLinkedCurrentWorkItem
FOR [ads_Warehouse].[dbo].vFactLinkedCurrentWorkItem
GO
 