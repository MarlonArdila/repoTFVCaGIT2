USE [ADSReports]
GO

/****** Object:  Table [dbo].[DiasEntreEstadosSinFestivos]    Script Date: 26/03/2020 7:29:04 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DiasEntreEstadosSinFestivos](
	[briefSysID] [int] NULL,
	[T1] [int] NULL,
	[T2] [int] NULL,
	[T3] [int] NULL,
	[T4] [int] NULL,
	[T5] [int] NULL,
	[E1] [int] NULL,
	[E2] [int] NULL,
	[E3] [int] NULL,
	[E4] [int] NULL
) ON [PRIMARY]

GO


